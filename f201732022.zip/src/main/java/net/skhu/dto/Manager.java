package net.skhu.dto;

import lombok.Data;

@Data
public class Manager {
	int id;
	String name;
	String phone;
	String office;
	String email;
	Project project;
    String priority;

}

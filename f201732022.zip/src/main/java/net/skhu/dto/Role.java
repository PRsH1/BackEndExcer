package net.skhu.dto;

public class Role {
	int id;
	String title;

}
